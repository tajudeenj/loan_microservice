package com.javaexpress.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.javaexpress.exceptions.LoanNotFoundException;
import com.javaexpress.model.Loans;
import com.javaexpress.repository.LoansRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LoansService {
	
	@Autowired
	LoansRepository loansRepository;
	

	
	public List <Loans>  fetchLoans(Integer customerId) {
		//Optional <Account> optional=accountRepository.findById(customerId);
		log.info(" fetchLoan customerID= {} ",customerId);
		//return loansRepository.findByCustomerId(customerId);
		
		List <Loans> loanList = loansRepository.findByCustomerId(customerId);
		log.info(" loan.isEmpty() = {} ",loanList.isEmpty());
				 
		 if (loanList!=null && loanList.size()>0) {
			 log.info(" fetchAccounts customerID= {} ",customerId);
			 return loanList;
						 
		 } else {
			 log.error("cutomer Not Found Exception { } ",customerId); //{} is used has 
			 throw new LoanNotFoundException("Customer Not Found Exception "+customerId);
		 }
		 
		 
	
	}
	

}
