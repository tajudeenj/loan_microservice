package com.javaexpress.config;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Configuration
@ConfigurationProperties(prefix = "loans")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LoansConfig {
	private String msg;
	private String buildVersion; //build_version
	private Map<String,String> mailDetails;
	private List<String> activeBranches;
	
	

} 
