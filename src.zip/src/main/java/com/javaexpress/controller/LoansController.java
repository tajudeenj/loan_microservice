package com.javaexpress.controller;


import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javaexpress.model.Loans;
import com.javaexpress.responses.PropertiesBo;
import com.javaexpress.config.LoansConfig;
import com.javaexpress.model.Customer;
import com.javaexpress.service.LoansService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;



@Slf4j
@RestController
@AllArgsConstructor
public class LoansController {
	
	//not required the autowired because the AllArgs annotaion in lombok will take care
	LoansService loansService;
	LoansConfig loansConfig;
		
	@PostMapping("/myLoans/{customerId}")
	public List<Loans>   retrievCards(@RequestBody @PathVariable("customerId")  Integer customerId)  {
		log.info("customerId = {}",customerId);
		  return loansService.fetchLoans(customerId);
		
	}
	
	//@PostMapping(value="/myLoans")
	@RequestMapping(value="/myLoans",
					method = RequestMethod.POST)
	public List<Loans> retrievAllCards(@RequestBody Customer customer) {
		log.info("--------------customerId = {}",customer.getCustomerId());
		return loansService.fetchLoans(customer.getCustomerId());
		//controller ->service layer  
	}
	
	
	/*
	//@GetMapping("/myAccount")
	public List <Account> fetchAccounts(@RequestBody  Customer customer) {
		log.info("Save Product method executed in controller getId {} ",customer.getCustomerId());
		return accountService.fetchAccount(customer.getCustomerId());
		
	}
	*/
	
	
	@GetMapping("/loan/branches")
	public List<String> getActiveBranches() {
		 return loansConfig.getActiveBranches();
		
	}
	
	@GetMapping("/loan/mails")
	public Map<String,String> getmailDetails() {
		return loansConfig.getMailDetails();
	}
	
	//http://localhost:8082/loan/properties
			@GetMapping("/loan/properties")
			public PropertiesBo  getAllProperties() {
				PropertiesBo bo = new PropertiesBo();
				 bo.setMsg(loansConfig.getMsg());
				 bo.setMailDetails(loansConfig.getMailDetails());
				 bo.setActiveBranches(loansConfig.getActiveBranches());
				 bo.setBuildVersion(loansConfig.getBuildVersion());
				 return bo;
						
			}
		
	
	
	

}
