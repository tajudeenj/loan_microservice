package com.javaexpress.model;




//@Entity

/*@Slf4j
@Setter
@Getter
@AllArgsConstructor
@ToString*/

public class Customer {
	
	
	public Customer() {
		
	}

	private int customerId;
	
	

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	

	
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.AUTO)
	 * 
	 * @Column(name="customer_id") private int customerId;
	 */

}
