package com.javaexpress.responses;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class PropertiesBo {
	private String msg;
	private String buildVersion; //build_version
	private Map<String,String> mailDetails;
	private List<String> activeBranches;
	
	
	

} 
