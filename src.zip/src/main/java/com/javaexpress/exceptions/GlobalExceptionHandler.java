package com.javaexpress.exceptions;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	
	//testcase http://localhost:8080/category/api/v1/fetch/4123
	
	@ExceptionHandler(LoanNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleException( LoanNotFoundException ex) {
		log.info("PAGE_NOT_FOUND_LOG_CATEGORY",PAGE_NOT_FOUND_LOG_CATEGORY);
		
		ErrorResponse erroResponse=ErrorResponse.builder()
				.timeStamp(LocalDateTime.now())
				.status(HttpStatus.BAD_REQUEST)
				.code(HttpStatus.BAD_REQUEST.value())
				.message("Invalid customer ID")
				.details(Collections.singletonList(ex.getLocalizedMessage()))
							.build();
		return new ResponseEntity<>(erroResponse,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleException(Exception ex) {
		ErrorResponse erroResponse=ErrorResponse.builder()
				.timeStamp(LocalDateTime.now())
				.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.code(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.message("Something went error  ")
				.details(Collections.singletonList(ex.getLocalizedMessage()))
							.build();
		return new ResponseEntity<>(erroResponse,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	public void handleException(Throwable th) {
	}
	
	
	@Override
	 protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body,HttpHeaders header,
			 HttpStatus status, WebRequest request ){
		
		ErrorResponse erroResponse= null;
		
		if( ex instanceof HttpRequestMethodNotSupportedException) {
			erroResponse=ErrorResponse.builder()
					.timeStamp(LocalDateTime.now())
					.status(HttpStatus.METHOD_NOT_ALLOWED)
					.code(HttpStatus.METHOD_NOT_ALLOWED.value())
					.message("Invalid Http Method  ")
					.details(Collections.singletonList(ex.getLocalizedMessage()))
								.build();
			return new ResponseEntity<>(erroResponse,HttpStatus.METHOD_NOT_ALLOWED);
			
		} else if(ex instanceof HttpMessageNotReadableException) {
			erroResponse=ErrorResponse.builder()
			.timeStamp(LocalDateTime.now())
			.status(HttpStatus.UNPROCESSABLE_ENTITY)
			.code(HttpStatus.UNPROCESSABLE_ENTITY.value())
			.message("Malformed JSON URL "+ex.getMessage())
			.details(Collections.singletonList(ex.getLocalizedMessage()))
						.build();
	return new ResponseEntity<>(erroResponse,HttpStatus.UNPROCESSABLE_ENTITY);
		 
		}
		return null;
		
	 }
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		log.info("handleMethodArgumentNotValid {}",HttpStatus.BAD_REQUEST);
		
		List <String> errorMessages = new ArrayList<>();
		 List <ObjectError>  errorList=  ex.getBindingResult().getAllErrors();
		 for (ObjectError err : errorList) {
			 errorMessages.add(err.getDefaultMessage());
		 }
		 
		ErrorResponse erroResponse=ErrorResponse.builder()
				.timeStamp(LocalDateTime.now())
				.status(HttpStatus.BAD_REQUEST)
				.code(HttpStatus.BAD_REQUEST.value())
				.message("Validation Failed")
				.details(errorMessages)
							.build();
		return new ResponseEntity<>(erroResponse,HttpStatus.BAD_REQUEST);
		
	}
	
	
	

}
